import { z } from 'zod';
import { streams } from './schema';

export const api = {
  stream: {
    status: {
      method: 'GET' as const,
      path: '/api/stream/status' as const,
      responses: {
        200: z.object({
          isActive: z.boolean(),
          viewerCount: z.number(),
          startedAt: z.string().nullable().optional(),
        }),
      },
    },
    start: {
      method: 'POST' as const,
      path: '/api/stream/start' as const,
      input: z.object({}),
      responses: {
        200: z.custom<typeof streams.$inferSelect>(),
      },
    },
    stop: {
      method: 'POST' as const,
      path: '/api/stream/stop' as const,
      input: z.object({}),
      responses: {
        200: z.custom<typeof streams.$inferSelect>(),
      },
    },
  },
};
