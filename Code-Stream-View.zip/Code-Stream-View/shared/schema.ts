import { pgTable, text, serial, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const streams = pgTable("streams", {
  id: serial("id").primaryKey(),
  isActive: boolean("is_active").default(false).notNull(),
  viewerCount: integer("viewer_count").default(0).notNull(),
  startedAt: timestamp("started_at"),
  lastHeartbeat: timestamp("last_heartbeat"),
});

export const insertStreamSchema = createInsertSchema(streams).omit({ 
  id: true, 
  lastHeartbeat: true 
});

export type Stream = typeof streams.$inferSelect;
export type InsertStream = z.infer<typeof insertStreamSchema>;
