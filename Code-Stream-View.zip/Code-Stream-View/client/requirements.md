## Packages
framer-motion | For cyberpunk animations and UI transitions
lucide-react | For terminal-style icons
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
The application is a pure viewer. 
The server handles the broadcasting logic (using @napi-rs/canvas as requested in prior context).
The client connects to `ws://host/ws` and receives binary image data (blobs) to render on a canvas.
No broadcasting logic on the client side.
Design is "cyberpunk hacker terminal dark-mode".
