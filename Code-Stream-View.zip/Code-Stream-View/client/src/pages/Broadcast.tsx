import { useEffect, useRef, useState } from "react";
import { Link, useLocation } from "wouter";
import { useStartStream, useStopStream, useStreamStatus } from "@/hooks/use-stream";
import { CyberButton } from "@/components/CyberButton";
import { ArrowLeft, Radio, Activity, Monitor } from "lucide-react";
import { GlitchText } from "@/components/GlitchText";

// --- Matrix Rain / Slot Animation Config ---
const SLOT_CONFIG = {
  fontSize: 24,
  columns: 40,
  speed: 1.5,
  decay: 0.95,
  glow: "#00ffcc",
};

export default function Broadcast() {
  const [location, setLocation] = useLocation();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { data: status } = useStreamStatus();
  const { mutate: startStream, isPending: isStarting } = useStartStream();
  const { mutate: stopStream, isPending: isStopping } = useStopStream();
  
  const wsRef = useRef<WebSocket | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationRef = useRef<number>(0);
  
  const [isBroadcasting, setIsBroadcasting] = useState(false);

  // Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    // Setup canvas dimensions
    const resize = () => {
      canvas.width = 1280;
      canvas.height = 720;
    };
    resize();

    // Characters for the matrix rain
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&";
    const columns = Math.floor(canvas.width / SLOT_CONFIG.fontSize);
    const drops: number[] = new Array(columns).fill(1);
    
    // Draw loop
    const render = () => {
      // Semi-transparent black for trail effect
      ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = SLOT_CONFIG.glow;
      ctx.font = `${SLOT_CONFIG.fontSize}px 'Share Tech Mono'`;

      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        const x = i * SLOT_CONFIG.fontSize;
        const y = drops[i] * SLOT_CONFIG.fontSize;

        // Randomly brighter characters
        if (Math.random() > 0.98) {
          ctx.fillStyle = "#fff";
        } else {
          ctx.fillStyle = SLOT_CONFIG.glow;
        }

        ctx.fillText(text, x, y);

        if (y > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }

      // HUD Overlay
      ctx.fillStyle = "rgba(0, 255, 204, 0.1)";
      ctx.fillRect(50, 50, 200, 100);
      ctx.strokeStyle = SLOT_CONFIG.glow;
      ctx.strokeRect(50, 50, 200, 100);
      
      ctx.fillStyle = "#fff";
      ctx.font = "16px 'Rajdhani'";
      ctx.fillText(`SYSTEM_TIME: ${Date.now()}`, 70, 90);
      ctx.fillText(`BROADCASTING: ${isBroadcasting ? 'TRUE' : 'FALSE'}`, 70, 120);

      animationRef.current = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animationRef.current);
  }, [isBroadcasting]);

  // Broadcasting Logic
  const handleStartBroadcast = async () => {
    if (!canvasRef.current) return;

    try {
      // 1. Notify backend
      startStream(undefined, {
        onSuccess: () => {
          // 2. Setup WebSocket
          const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
          const wsUrl = `${protocol}//${window.location.host}/ws?role=broadcaster`;
          const ws = new WebSocket(wsUrl);
          wsRef.current = ws;

          ws.onopen = () => {
            console.log("Broadcaster connected");
            
            // 3. Capture Canvas Stream
            const stream = canvasRef.current!.captureStream(30); // 30 FPS
            streamRef.current = stream;

            // 4. Setup MediaRecorder
            const mediaRecorder = new MediaRecorder(stream, {
              mimeType: 'video/webm; codecs=vp9',
              videoBitsPerSecond: 3000000 // 3 Mbps
            });

            mediaRecorder.ondataavailable = (event) => {
              if (event.data.size > 0 && ws.readyState === WebSocket.OPEN) {
                ws.send(event.data);
              }
            };

            mediaRecorder.start(100); // 100ms chunks
            mediaRecorderRef.current = mediaRecorder;
            setIsBroadcasting(true);
          };

          ws.onclose = () => {
            console.log("Broadcaster disconnected");
            setIsBroadcasting(false);
          };
        }
      });
    } catch (err) {
      console.error("Failed to start broadcast", err);
    }
  };

  const handleStopBroadcast = () => {
    stopStream(undefined, {
      onSuccess: () => {
        mediaRecorderRef.current?.stop();
        streamRef.current?.getTracks().forEach(track => track.stop());
        wsRef.current?.close();
        setIsBroadcasting(false);
      }
    });
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 lg:p-8 flex flex-col gap-6">
      {/* Header */}
      <div className="flex justify-between items-center border-b border-white/10 pb-6">
        <div className="flex items-center gap-4">
          <Link href="/">
            <button className="p-2 hover:bg-white/5 rounded transition-colors text-muted-foreground hover:text-primary">
              <ArrowLeft className="w-6 h-6" />
            </button>
          </Link>
          <div>
            <h1 className="text-2xl font-mono text-primary font-bold flex items-center gap-2">
              <Radio className="w-6 h-6" />
              TRANSMITTER_V1
            </h1>
            <p className="text-sm text-muted-foreground font-mono">Secure Uplink Interface</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="text-right hidden md:block">
            <p className="text-xs text-muted-foreground font-mono">UPLINK STATUS</p>
            <p className={`font-bold font-mono ${isBroadcasting ? 'text-green-500' : 'text-zinc-500'}`}>
              {isBroadcasting ? 'TRANSMITTING' : 'IDLE'}
            </p>
          </div>
        </div>
      </div>

      {/* Main Control Panel */}
      <div className="flex flex-col lg:flex-row gap-8 flex-1">
        {/* Preview Monitor */}
        <div className="flex-1 relative bg-zinc-900/30 border border-white/10 rounded-lg overflow-hidden group">
          <div className="absolute top-4 left-4 z-10 flex gap-2">
            <div className="px-2 py-1 bg-black/80 border border-primary/30 text-[10px] font-mono text-primary flex items-center gap-1">
              <Monitor className="w-3 h-3" /> PREVIEW
            </div>
            {isBroadcasting && (
              <div className="px-2 py-1 bg-red-500/10 border border-red-500/50 text-[10px] font-mono text-red-500 flex items-center gap-1 animate-pulse">
                <Activity className="w-3 h-3" /> ON AIR
              </div>
            )}
          </div>

          <canvas 
            ref={canvasRef}
            className="w-full h-full object-contain bg-black"
          />
          
          {/* CRT Scanline Effect */}
          <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)50%,rgba(0,0,0,0.25)50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />
        </div>

        {/* Sidebar Controls */}
        <div className="w-full lg:w-80 flex flex-col gap-6">
          <div className="p-6 bg-zinc-900/20 border border-white/5 space-y-6 clip-path-slant">
            <div>
              <h2 className="text-lg font-mono text-white mb-4 flex items-center gap-2">
                <Terminal className="w-4 h-4 text-secondary" />
                COMMANDS
              </h2>
              
              {!isBroadcasting ? (
                <CyberButton 
                  onClick={handleStartBroadcast}
                  disabled={isStarting}
                  className="w-full h-16 text-lg"
                >
                  {isStarting ? "INITIALIZING..." : "INITIATE_STREAM"}
                </CyberButton>
              ) : (
                <CyberButton 
                  onClick={handleStopBroadcast}
                  disabled={isStopping}
                  variant="danger"
                  className="w-full h-16 text-lg"
                >
                  {isStopping ? "TERMINATING..." : "KILL_SIGNAL"}
                </CyberButton>
              )}
            </div>

            <div className="space-y-4 pt-4 border-t border-white/5">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-muted-foreground">
                  <span>BITRATE</span>
                  <span>3000 KBPS</span>
                </div>
                <div className="h-1 bg-white/10 overflow-hidden">
                  <div className="h-full bg-primary w-3/4 animate-pulse" />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-muted-foreground">
                  <span>FPS</span>
                  <span>30</span>
                </div>
                <div className="h-1 bg-white/10 overflow-hidden">
                  <div className="h-full bg-secondary w-full" />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-muted-foreground">
                  <span>LATENCY</span>
                  <span>~150ms</span>
                </div>
                <div className="h-1 bg-white/10 overflow-hidden">
                  <div className="h-full bg-accent w-1/4" />
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 bg-zinc-900/20 border border-white/5 flex-1">
            <h3 className="text-xs font-mono text-muted-foreground mb-4">SYSTEM_LOG</h3>
            <div className="font-mono text-xs space-y-1 text-zinc-500 h-40 overflow-hidden relative">
              <p>[INFO] System initialized...</p>
              <p>[INFO] Canvas context acquired...</p>
              <p>[INFO] Audio device skipped (video only)...</p>
              {isBroadcasting && (
                <>
                  <p className="text-primary">[SUCCESS] Uplink established</p>
                  <p className="text-white">[STREAM] Sending packets...</p>
                </>
              )}
              <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-black to-transparent" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
