import React, { useEffect, useRef, useState } from 'react';
import { useStreamStatus } from '@/hooks/use-stream';
import { TerminalOverlay } from '@/components/TerminalOverlay';
import { CyberButton } from '@/components/CyberButton';
import { Wifi, WifiOff, Users, Activity, Radio } from 'lucide-react';

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [latency, setLatency] = useState(0);
  const { data: status } = useStreamStatus();
  const lastFrameTime = useRef<number>(Date.now());

  useEffect(() => {
    // Determine WS protocol
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const connect = () => {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;
      ws.binaryType = 'arraybuffer'; // Expecting binary image data

      ws.onopen = () => {
        setIsConnected(true);
        console.log('[SYSTEM] Connected to Neural Net');
      };

      ws.onmessage = async (event) => {
        if (event.data instanceof ArrayBuffer) {
          const blob = new Blob([event.data], { type: 'image/jpeg' });
          const url = URL.createObjectURL(blob);
          const img = new Image();
          
          img.onload = () => {
            const canvas = canvasRef.current;
            if (canvas) {
              const ctx = canvas.getContext('2d', { alpha: false }); // alpha: false for performance
              if (ctx) {
                // Ensure canvas fills the screen or maintains aspect ratio
                // For this cyberpunk terminal feel, we want it to fill the container
                // but maintain pixel sharpness if possible.
                
                // Let's draw it covering the canvas
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                
                // Calculate pseudo-latency (frame gap)
                const now = Date.now();
                setLatency(now - lastFrameTime.current);
                lastFrameTime.current = now;
              }
            }
            URL.revokeObjectURL(url);
          };
          img.src = url;
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
        console.log('[SYSTEM] Connection Lost. Retrying...');
        // Simple reconnect logic
        setTimeout(connect, 3000);
      };

      ws.onerror = (err) => {
        console.error('[SYSTEM] Error:', err);
      };
    };

    connect();

    return () => {
      wsRef.current?.close();
    };
  }, []);

  // Handle canvas resizing
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        // Set internal resolution to match window size for sharpness
        // Or set it to a fixed retro resolution like 1920x1080 and let CSS scale it
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
      }
    };
    
    window.addEventListener('resize', handleResize);
    handleResize(); // Init

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="relative w-screen h-screen bg-black overflow-hidden flex flex-col items-center justify-center">
      {/* Background Grid - subtle */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: `linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }}
      />
      
      {/* Scanline Effect */}
      <div className="scanline" />
      
      {/* CRT Vignette */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle,transparent_50%,rgba(0,0,0,0.8)_100%)] z-20" />

      {/* Main Stream Canvas */}
      <canvas 
        ref={canvasRef}
        className="block w-full h-full object-cover z-10"
      />

      {/* UI Overlay - Top Right Status */}
      <div className="absolute top-6 right-6 z-50 flex flex-col items-end gap-2 pointer-events-none">
        <div className="flex items-center gap-2 bg-black/80 border border-primary/30 px-3 py-1 backdrop-blur text-primary text-xs font-mono">
          {isConnected ? (
            <>
              <Wifi className="w-3 h-3 animate-pulse" />
              <span>SIGNAL: STRONG</span>
            </>
          ) : (
            <>
              <WifiOff className="w-3 h-3 text-destructive animate-pulse" />
              <span className="text-destructive">SIGNAL: LOST</span>
            </>
          )}
        </div>
        
        <div className="flex items-center gap-2 bg-black/80 border border-primary/30 px-3 py-1 backdrop-blur text-primary text-xs font-mono">
          <Users className="w-3 h-3" />
          <span>VIEWERS: {status?.viewerCount || 0}</span>
        </div>

        <div className="flex items-center gap-2 bg-black/80 border border-primary/30 px-3 py-1 backdrop-blur text-primary text-xs font-mono">
          <Activity className="w-3 h-3" />
          <span>FPS: {latency > 0 ? Math.min(60, Math.round(1000 / latency)) : 0}</span>
        </div>
      </div>

      {/* Terminal Logs Overlay */}
      <TerminalOverlay />

      {/* Bottom Control Bar */}
      <div className="absolute bottom-0 left-0 w-full p-6 z-50 pointer-events-none flex justify-between items-end bg-gradient-to-t from-black/90 to-transparent">
        <div className="pointer-events-auto">
          <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary text-glow mb-2 font-display">
            NEURAL_LINK
          </h1>
          <p className="text-primary/60 font-mono text-sm tracking-widest uppercase">
            &gt; SYSTEM_READY // WAITING_FOR_INPUT
          </p>
        </div>

        <div className="pointer-events-auto flex gap-4">
           {/* This button could trigger a "full screen" or other client-side effect */}
          <CyberButton 
            onClick={() => document.documentElement.requestFullscreen()}
            variant="ghost"
            className="hidden md:block"
          >
            [ FULLSCREEN ]
          </CyberButton>
          
          <div className="flex items-center gap-2 text-destructive font-mono text-xs border border-destructive/30 px-3 py-2 bg-destructive/5 animate-pulse">
             <Radio className="w-3 h-3" />
             <span>LIVE FEED</span>
          </div>
        </div>
      </div>

      {/* Loading State / No Stream State */}
      {!isConnected && (
        <div className="absolute inset-0 flex items-center justify-center z-40 bg-black/90">
          <div className="flex flex-col items-center gap-4">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-primary font-mono text-lg animate-pulse">CONNECTING TO MAINFRAME...</p>
          </div>
        </div>
      )}
    </div>
  );
}
