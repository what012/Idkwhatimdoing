import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-black text-primary font-mono p-4">
      <div className="w-full max-w-md border border-destructive/50 bg-black/50 p-8 shadow-[0_0_50px_rgba(255,0,0,0.2)] backdrop-blur relative overflow-hidden">
        {/* Decorative corner markers */}
        <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-destructive" />
        <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-destructive" />
        <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-destructive" />
        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-destructive" />
        
        <div className="flex flex-col items-center text-center gap-6 relative z-10">
          <AlertTriangle className="h-20 w-20 text-destructive animate-pulse" />
          
          <h1 className="text-4xl font-bold tracking-tighter text-destructive">
            404_ERROR
          </h1>
          
          <p className="text-muted-foreground text-sm uppercase tracking-widest border-t border-b border-destructive/20 py-2 w-full">
            Sector Not Found
          </p>
          
          <p className="text-sm text-primary/80">
            The requested data coordinates do not exist in the current memory bank.
          </p>

          <Link href="/" className="mt-4 px-8 py-3 bg-destructive/10 border border-destructive text-destructive hover:bg-destructive hover:text-black transition-all duration-300 font-bold uppercase tracking-widest text-sm">
            Return to Grid
          </Link>
        </div>

        {/* Background noise effect */}
        <div className="absolute inset-0 pointer-events-none opacity-10 bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />
      </div>
    </div>
  );
}
