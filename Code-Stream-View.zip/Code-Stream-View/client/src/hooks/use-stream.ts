import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertStream } from "@shared/routes";

// Hook for fetching stream status
export function useStreamStatus() {
  return useQuery({
    queryKey: [api.stream.status.path],
    queryFn: async () => {
      const res = await fetch(api.stream.status.path);
      if (!res.ok) throw new Error("Failed to fetch stream status");
      return api.stream.status.responses[200].parse(await res.json());
    },
    // Poll every 5 seconds to keep viewer count updated
    refetchInterval: 5000, 
  });
}

// Hook to start the stream (Server-side broadcasting triggers)
export function useStartStream() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.stream.start.path, {
        method: api.stream.start.method,
      });
      if (!res.ok) throw new Error("Failed to start stream");
      return api.stream.start.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.stream.status.path] });
    },
  });
}

// Hook to stop the stream
export function useStopStream() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.stream.stop.path, {
        method: api.stream.stop.method,
      });
      if (!res.ok) throw new Error("Failed to stop stream");
      return api.stream.stop.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.stream.status.path] });
    },
  });
}
