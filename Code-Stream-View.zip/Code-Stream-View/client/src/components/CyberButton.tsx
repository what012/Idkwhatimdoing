import React from 'react';
import { cn } from "@/lib/utils";

interface CyberButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'danger' | 'ghost';
  children: React.ReactNode;
}

export function CyberButton({ 
  className, 
  variant = 'primary', 
  children, 
  ...props 
}: CyberButtonProps) {
  const variants = {
    primary: "border-primary text-primary hover:bg-primary/10 shadow-[0_0_15px_rgba(0,255,255,0.3)] hover:shadow-[0_0_25px_rgba(0,255,255,0.5)]",
    danger: "border-destructive text-destructive hover:bg-destructive/10 shadow-[0_0_15px_rgba(255,0,0,0.3)] hover:shadow-[0_0_25px_rgba(255,0,0,0.5)]",
    ghost: "border-transparent text-muted-foreground hover:text-primary hover:bg-primary/5"
  };

  return (
    <button
      className={cn(
        "relative px-6 py-2 font-mono text-sm uppercase tracking-widest transition-all duration-200",
        "border-2 bg-black/80 backdrop-blur-sm",
        "before:absolute before:top-0 before:left-0 before:w-2 before:h-2 before:border-t-2 before:border-l-2 before:border-inherit before:content-['']",
        "after:absolute after:bottom-0 after:right-0 after:w-2 after:h-2 after:border-b-2 after:border-r-2 after:border-inherit after:content-['']",
        "active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed",
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
