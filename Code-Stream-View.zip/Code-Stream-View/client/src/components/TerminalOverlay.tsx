import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export function TerminalOverlay() {
  const [lines, setLines] = useState<string[]>([]);

  useEffect(() => {
    const messages = [
      "ESTABLISHING SECURE CONNECTION...",
      "HANDSHAKE PROTOCOL: INITIATED",
      "ENCRYPTION KEY: [****************]",
      "SIGNAL STRENGTH: 100%",
      "ACCESS GRANTED",
      "SYSTEM: ONLINE",
      "STREAM: RECEIVING DATA PACKETS"
    ];

    let delay = 0;
    messages.forEach((msg, index) => {
      delay += Math.random() * 500 + 200;
      setTimeout(() => {
        setLines(prev => [...prev.slice(-4), `> ${msg}`]);
      }, delay);
    });
  }, []);

  return (
    <div className="absolute top-4 left-4 z-50 pointer-events-none font-mono text-xs md:text-sm text-primary/80">
      <div className="flex flex-col gap-1">
        <AnimatePresence>
          {lines.map((line, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
              className="bg-black/50 px-2 py-1 border-l-2 border-primary/50"
            >
              {line}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
