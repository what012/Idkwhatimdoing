import { createCanvas, Canvas, CanvasRenderingContext2D } from '@napi-rs/canvas';
import { WebSocketServer, WebSocket } from 'ws';

// Configuration
const CHAR_W = 38;
const CHAR_H = 60;
const CANVAS_WIDTH = 1920; // Full HD
const CANVAS_HEIGHT = 1080;
const FPS = 30;

// State
let canvas: Canvas;
let ctx: CanvasRenderingContext2D;
let cacheCanvas: Canvas;
let slots: Array<{ index: number; progress: number }> = [];
let velocity = 0.005;
const accel = 1.002;
const maxVelocity = 0.1;

const alphabet = "abcdefghijklmnopqrstuvwxyzåäö".split("");
const base = alphabet.length;

// Pre-render cache
function initCache() {
  cacheCanvas = createCanvas(CHAR_W, CHAR_H * base);
  const cCtx = cacheCanvas.getContext('2d');
  cCtx.font = "bold 45px 'Courier New', monospace";
  cCtx.textAlign = "center";
  cCtx.textBaseline = "middle";
  cCtx.fillStyle = "#00ffcc";

  alphabet.forEach((char, i) => {
    cCtx.fillText(char, CHAR_W / 2, (i + 0.5) * CHAR_H);
  });
}

function initSlots() {
  const cols = Math.ceil(CANVAS_WIDTH / CHAR_W) + 1;
  slots = Array.from({ length: cols }, () => ({ index: 0, progress: 0 }));
}

function tick(slotIdx: number, amount: number) {
  const s = slots[slotIdx];
  s.progress += amount;
  const steps = Math.floor(s.progress);
  s.progress -= steps;
  const prevIndex = s.index;
  s.index = (s.index + steps) % base;

  if (s.index < prevIndex) {
    if (slotIdx > 0) {
      tick(slotIdx - 1, 1);
    }
  }
}

function render() {
  velocity = Math.min(velocity * accel, maxVelocity);
  tick(slots.length - 1, velocity);

  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  // Center vertical alignment
  const startY = (CANVAS_HEIGHT - CHAR_H * 3) / 2;

  slots.forEach((s, xIdx) => {
    const x = xIdx * CHAR_W;
    const visualScroll = s.progress * CHAR_H;

    for (let yOffset = -2; yOffset <= 4; yOffset++) { // Draw more vertical context
      const targetIdx = ((s.index - yOffset) % base + base) % base;
      const sourceY = targetIdx * CHAR_H;
      const destY = startY + (yOffset + 1) * CHAR_H + visualScroll;
      
      ctx.drawImage(cacheCanvas, 
        0, sourceY, CHAR_W, CHAR_H, 
        x, destY, CHAR_W, CHAR_H
      );
    }
  });
}

export function startBroadcaster(wss: WebSocketServer) {
  canvas = createCanvas(CANVAS_WIDTH, CANVAS_HEIGHT);
  ctx = canvas.getContext('2d');
  initCache();
  initSlots();

  setInterval(() => {
    render();
    // Compress to JPEG with 70% quality for speed
    const buffer = canvas.toBuffer('image/jpeg', 70);
    
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(buffer);
      }
    });
  }, 1000 / FPS);
}
