import { db } from "./db";
import { streams, type Stream, type InsertStream } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getStreamStatus(): Promise<Stream | undefined>;
  startStream(): Promise<Stream>;
  stopStream(): Promise<Stream>;
  updateViewerCount(count: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getStreamStatus(): Promise<Stream | undefined> {
    const [stream] = await db.select().from(streams).limit(1);
    return stream;
  }

  async startStream(): Promise<Stream> {
    const existing = await this.getStreamStatus();
    if (existing) {
      const [updated] = await db
        .update(streams)
        .set({ isActive: true, startedAt: new Date() })
        .where(eq(streams.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(streams)
        .values({ isActive: true, startedAt: new Date(), viewerCount: 0 })
        .returning();
      return created;
    }
  }

  async stopStream(): Promise<Stream> {
    const existing = await this.getStreamStatus();
    if (existing) {
      const [updated] = await db
        .update(streams)
        .set({ isActive: false, startedAt: null })
        .where(eq(streams.id, existing.id))
        .returning();
      return updated;
    }
    // Should not happen if startStream creates one, but safe fallback
    const [created] = await db
      .insert(streams)
      .values({ isActive: false, viewerCount: 0 })
      .returning();
    return created;
  }

  async updateViewerCount(count: number): Promise<void> {
    const existing = await this.getStreamStatus();
    if (existing) {
      await db
        .update(streams)
        .set({ viewerCount: count })
        .where(eq(streams.id, existing.id));
    }
  }
}

export const storage = new DatabaseStorage();
