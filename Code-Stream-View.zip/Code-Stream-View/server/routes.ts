import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { WebSocketServer } from "ws";
import { startBroadcaster } from "./broadcaster";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // --- HTTP Routes ---
  
  app.get(api.stream.status.path, async (req, res) => {
    const stream = await storage.getStreamStatus();
    res.json({
      isActive: stream?.isActive ?? true, // Always active now
      viewerCount: stream?.viewerCount ?? 0,
      startedAt: stream?.startedAt ? stream.startedAt.toISOString() : new Date().toISOString(),
    });
  });

  app.post(api.stream.start.path, async (req, res) => {
    const stream = await storage.startStream();
    res.json(stream);
  });

  app.post(api.stream.stop.path, async (req, res) => {
    const stream = await storage.stopStream();
    res.json(stream);
  });

  // --- WebSocket Server ---
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Start the server-side broadcaster
  startBroadcaster(wss);

  wss.on('connection', (ws) => {
    storage.updateViewerCount(wss.clients.size);
    
    ws.on('close', () => {
      storage.updateViewerCount(wss.clients.size);
    });
  });

  return httpServer;
}
